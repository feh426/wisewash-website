(function(){
  document.documentElement.classList.add('js');
  var reduce = window.matchMedia && window.matchMedia('(prefers-reduced-motion: reduce)').matches;

  /* menu */
  var hdr = document.querySelector('.hdr'), mb = document.querySelector('.menu-btn');
  if (hdr && mb) {
    mb.addEventListener('click', function(){
      var open = hdr.getAttribute('data-open') === '1';
      hdr.setAttribute('data-open', open ? '0' : '1');
      mb.setAttribute('aria-expanded', String(!open));
      mb.textContent = open ? 'Menu' : 'Close';
    });
  }

  /* reveal on scroll, with a safety net so nothing stays hidden */
  var rv = [].slice.call(document.querySelectorAll('.rv'));
  if ('IntersectionObserver' in window && !reduce) {
    var io = new IntersectionObserver(function(es){
      es.forEach(function(e){ if (e.isIntersecting) { e.target.classList.add('in'); io.unobserve(e.target); } });
    }, { rootMargin: '0px 0px -8% 0px', threshold: 0.08 });
    rv.forEach(function(el){ io.observe(el); });
    setTimeout(function(){ rv.forEach(function(el){ el.classList.add('in'); }); }, 2500);
  } else {
    rv.forEach(function(el){ el.classList.add('in'); });
  }

  /* ledger readouts */
  document.querySelectorAll('[data-ledger]').forEach(function(box){
    var rows = box.querySelectorAll('tbody tr[data-say]');
    var out = box.querySelector('.readout');
    var base = out ? out.innerHTML : '';
    function say(r){ rows.forEach(function(x){ x.classList.toggle('on', x === r); }); if (out) out.innerHTML = r ? '<b>' + r.querySelector('th').textContent.trim() + '.</b> ' + r.getAttribute('data-say') : base; }
    rows.forEach(function(r){
      r.addEventListener('mouseenter', function(){ say(r); });
      r.addEventListener('focus', function(){ say(r); });
      r.addEventListener('click', function(){ say(r); });
      r.setAttribute('tabindex', '0');
    });
    box.addEventListener('mouseleave', function(){ say(null); });
  });

  /* count-up figures */
  function countUp(el){
    var target = parseFloat(el.getAttribute('data-count')), dec = (el.getAttribute('data-dec') || '0') | 0;
    var suffix = el.getAttribute('data-suffix') || '', prefix = el.getAttribute('data-prefix') || '';
    var t0 = null, dur = 1400;
    function fmt(v){ return prefix + v.toLocaleString('en-US', { minimumFractionDigits: dec, maximumFractionDigits: dec }) + suffix; }
    if (reduce) { el.textContent = fmt(target); return; }
    function step(t){ if (!t0) t0 = t; var p = Math.min(1, (t - t0) / dur); var e = 1 - Math.pow(1 - p, 3); el.textContent = fmt(target * e); if (p < 1) requestAnimationFrame(step); }
    requestAnimationFrame(step);
  }
  var counters = [].slice.call(document.querySelectorAll('[data-count]'));
  if ('IntersectionObserver' in window) {
    var io2 = new IntersectionObserver(function(es){ es.forEach(function(e){ if (e.isIntersecting) { countUp(e.target); io2.unobserve(e.target); } }); }, { threshold: 0.4 });
    counters.forEach(function(c){ io2.observe(c); });
  } else { counters.forEach(countUp); }

  /* hero tunnel: receding arches of light drawn on canvas */
  var cv = document.getElementById('tunnel');
  if (cv && cv.getContext) {
    var ctx = cv.getContext('2d'), W, H, dpr, t = 0, raf;
    function size(){ dpr = Math.min(2, window.devicePixelRatio || 1); W = cv.clientWidth; H = cv.clientHeight; cv.width = W * dpr; cv.height = H * dpr; ctx.setTransform(dpr, 0, 0, dpr, 0, 0); }
    function arch(cx, baseY, w, h, alpha, lw){
      ctx.beginPath();
      ctx.moveTo(cx - w / 2, baseY);
      ctx.lineTo(cx - w / 2, baseY - h * 0.55);
      ctx.quadraticCurveTo(cx - w / 2, baseY - h, cx - w * 0.18, baseY - h);
      ctx.lineTo(cx + w * 0.18, baseY - h);
      ctx.quadraticCurveTo(cx + w / 2, baseY - h, cx + w / 2, baseY - h * 0.55);
      ctx.lineTo(cx + w / 2, baseY);
      ctx.strokeStyle = 'rgba(127,210,169,' + alpha + ')';
      ctx.lineWidth = lw;
      ctx.stroke();
    }
    function frame(){
      ctx.clearRect(0, 0, W, H);
      var cx = W * 0.72, baseY = H * 1.02, n = 14;
      var glow = ctx.createRadialGradient(cx, H * 0.55, 10, cx, H * 0.55, Math.max(W, H) * 0.7);
      glow.addColorStop(0, 'rgba(127,210,169,.16)'); glow.addColorStop(1, 'rgba(127,210,169,0)');
      ctx.fillStyle = glow; ctx.fillRect(0, 0, W, H);
      for (var i = n; i >= 0; i--) {
        var k = (i + (reduce ? 0 : (t % 1))) / n;           /* 0 = far, 1 = near */
        var s = Math.pow(k, 1.9);
        var w = 60 + s * W * 1.35, h = 40 + s * H * 1.15;
        var alpha = 0.05 + s * 0.34, lw = 1 + s * 2.4;
        arch(cx, baseY, w, h, alpha, lw);
      }
      /* floor lines */
      ctx.strokeStyle = 'rgba(127,210,169,.08)'; ctx.lineWidth = 1;
      for (var j = -3; j <= 3; j++) { ctx.beginPath(); ctx.moveTo(cx + j * 22, H * 0.62); ctx.lineTo(cx + j * 260, baseY); ctx.stroke(); }
      if (!reduce) { t += 0.004; raf = requestAnimationFrame(frame); }
    }
    size(); frame();
    window.addEventListener('resize', function(){ size(); if (reduce) frame(); });
    document.addEventListener('visibilitychange', function(){ if (document.hidden) cancelAnimationFrame(raf); else if (!reduce) raf = requestAnimationFrame(frame); });
  }

  /* contact form: composes an email in the visitor's mail client */
  var f = document.getElementById('inquiry');
  if (f) {
    f.addEventListener('submit', function(e){
      e.preventDefault();
      if (f.querySelector('.hp input') && f.querySelector('.hp input').value) return;
      var g = function(n){ var el = f.elements[n]; return el ? el.value.trim() : ''; };
      var body = ['I am: ' + g('who'), 'Interested in: ' + g('interest'), 'Situation: ' + g('situation'), 'Name: ' + g('name'), 'Email: ' + g('email'), 'Company: ' + g('company'), 'Location: ' + g('location'), '', g('message')].join('\n');
      var to = f.getAttribute('data-to');
      window.location.href = 'mailto:' + to + '?subject=' + encodeURIComponent('WiseWash inquiry: ' + (g('interest') || 'General')) + '&body=' + encodeURIComponent(body);
      f.classList.add('sent');
    });
    var q = new URLSearchParams(location.search).get('situation');
    if (q === 'pressure' && f.elements['situation']) f.elements['situation'].value = 'Loan in default or site under pressure';
  }
})();
